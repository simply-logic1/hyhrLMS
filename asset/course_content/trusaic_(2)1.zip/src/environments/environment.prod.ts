export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyAnn7qflhBDVz_WvNUyTlk2myq0bzq2cJU",
    authDomain: "trusaic-hosu.firebaseapp.com",
    databaseURL: "https://trusaic-hosu.firebaseio.com",
    projectId: "trusaic-hosu",
    storageBucket: "trusaic-hosu.appspot.com",
    messagingSenderId: "292674414684",
    appId: "1:292674414684:web:0ac2caafb7c2bab0e69e99"
  }
};
