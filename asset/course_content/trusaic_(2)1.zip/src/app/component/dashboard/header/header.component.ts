import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router: Router) { }

  @Output() searchdate =  new EventEmitter();

  ngOnInit(): void {
  }

  date(value){
    this.searchdate.emit(value);
  }

  logout(){
    localStorage.removeItem("email");
    this.router.navigate(['/login']);
  }
  

}
