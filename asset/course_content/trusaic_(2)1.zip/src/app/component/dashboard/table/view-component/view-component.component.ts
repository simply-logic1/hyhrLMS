import { Component, OnInit, Inject} from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { AngularFirestore } from 'angularfire2/firestore';

import { TableComponent } from '../table.component';

@Component({
  selector: 'app-view-component',
  templateUrl: './view-component.component.html',
  styleUrls: ['./view-component.component.css']
})
export class ViewComponentComponent implements OnInit {

  limitData: any[] = [];
  constructor(private db: AngularFirestore, public dialogRef: MatDialogRef<TableComponent>,@Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit(): void {
    this.db.collection('message').snapshotChanges().subscribe(user=> {
      this.limitData = [];
      return user.map(a=>{
        const data = a.payload.doc.data();
        const id = a.payload.doc.id;
        
        this.db.doc('message/'+id).collection(id).snapshotChanges().subscribe(data => {
          return data.map(b=>{
            const data = b.payload.doc.data();
            const id = b.payload.doc.id;
            this.limitData.push(data);
          });
        });
        
      });
    });
  }

}
