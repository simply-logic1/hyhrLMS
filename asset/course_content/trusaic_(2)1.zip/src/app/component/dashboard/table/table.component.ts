import { Component, OnInit, ViewChild } from '@angular/core';
import { FireService } from '../../../services/firebase/fire.service';
import { MatDialog } from '@angular/material/dialog';
import { ViewComponentComponent } from './view-component/view-component.component';


import { MatPaginator } from '@angular/material/paginator'; 
import { MatTableDataSource } from '@angular/material/table';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  dialogflow: MatTableDataSource<any>;
  @ViewChild('DialogflowPaginator', {static: true}) dialogflowPaginator: MatPaginator;
 

  constructor(private db: FireService, private dialog: MatDialog) {
    this.dialogflow = new MatTableDataSource;

   }
  data:any;
  users: any;

  dataSource:any[] = [];

  displayedColumns: string[] = ['date', 'req', 'action'];



  ngOnInit(): void {
    this.users = this.db.getData().snapshotChanges().subscribe(user => {
      this.dataSource = [];
    return user.map(a=>{
      const data = a.payload.doc.data();
      const id = a.payload.doc.id;
      this.dataSource.push(data);
      const element : any[] = this.dataSource; 
      this.dialogflow.data = element;
      this.dialogflow.paginator = this.dialogflowPaginator;
    });
      /*
      this.dataSource = [];
      user.forEach(element =>{
        var y = element.payload.toJSON();
        y['$key'] = element.key;
        this.dataSource.push(y);
      });
      const element : any[] = this.dataSource; 
      this.dialogflow.data = element;
      this.dialogflow.paginator = this.dialogflowPaginator;
      */
    });
  }

  


  views(element){
    this.dialog.open(ViewComponentComponent,{
      data: element
    })
  }

  date(searchdate){
    let dd = String(searchdate.value.getDate()).padStart(2, '0');
    let mm = String(searchdate.value.getMonth() + 1); //January is 0!
    let yyyy = searchdate.value.getFullYear();
    let time = dd + "/" +mm+ "/" + yyyy;
    this.dialogflow.filter = time;
  }

  delete(id: string){
    if(confirm("Are you sure to delete?")){
      this.db.delete(id);
    }
  }
}

