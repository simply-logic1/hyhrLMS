import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore } from 'angularfire2/firestore';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  data:any;
  constructor(private router: Router, private db: AngularFirestore) { }

  ngOnInit(): void {
  }

  login(login){
    const email = login.value.email;
    const password = login.value.password;

    this.db.collection('login').valueChanges().subscribe(user => {
      this.data = user;
      if(this.data[0].email == email && this.data[0].password == password){
        localStorage.setItem("email", this.data[0].email);
        this.router.navigate(['/dashboard']);
      }
    });
    
  }
}
