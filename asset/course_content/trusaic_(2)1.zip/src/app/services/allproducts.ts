export interface Allproducts{
    $key : String,
    product_name: String,
    product_category: String,
    product_rate: String,
    Product_quantity: String,
    available: true
}