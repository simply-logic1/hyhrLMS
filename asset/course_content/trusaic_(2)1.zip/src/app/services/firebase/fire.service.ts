import { Injectable } from '@angular/core';
import { AngularFirestore } from 'angularfire2/firestore';

@Injectable({
  providedIn: 'root'
})
export class FireService {

  constructor(private db: AngularFirestore) { }

  //limitData: AngularFireList<any>;

  getData(){
    return this.db.collection('message');
  }

  delete(id){
    this.db.doc('message/'+id).delete();
  }

}
