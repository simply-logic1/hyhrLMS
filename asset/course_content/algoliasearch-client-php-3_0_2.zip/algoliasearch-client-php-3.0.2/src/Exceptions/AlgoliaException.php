<?php

namespace Algolia\AlgoliaSearch\Exceptions;

class AlgoliaException extends \Exception
{
}
