<?php

namespace Algolia\AlgoliaSearch\Exceptions;

class MissingObjectId extends AlgoliaException
{
}
